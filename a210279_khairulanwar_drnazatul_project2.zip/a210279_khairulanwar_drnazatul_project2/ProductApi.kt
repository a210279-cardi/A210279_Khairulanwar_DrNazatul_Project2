package com.example.a210279_khairulanwar_drnazatul_project2

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Url

// =============================
// API SERVICE
// =============================

interface ProductApi {

    /**
     * Dynamically fetches data using a full URL path.
     * This allows us to pass a specific URL for food or beauty products dynamically.
     * * For Food: "https://world.openfoodfacts.org/api/v0/product/{barcode}.json"
     * For Beauty/Skincare/Haircare: "https://beauty.openfoodfacts.org/api/v0/product/{barcode}.json"
     */
    @GET
    suspend fun getProduct(
        @Url url: String
    ): ProductResponse
}

// =============================
// RETROFIT INSTANCE
// =============================

object RetrofitInstance {

    val api: ProductApi by lazy {
        Retrofit.Builder()
            // Using a generic placeholder base URL because the @Url parameter completely overrides it
            .baseUrl("https://openfoodfacts.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ProductApi::class.java)
    }
}

// =============================
// JSON DATA MODELS
// =============================

data class ProductResponse(
    val status: Int,
    val product: ProductData?
)

data class ProductData(
    val product_name: String?,
    val ingredients_text: String?,
    val categories: String?,
    val image_url: String?
)