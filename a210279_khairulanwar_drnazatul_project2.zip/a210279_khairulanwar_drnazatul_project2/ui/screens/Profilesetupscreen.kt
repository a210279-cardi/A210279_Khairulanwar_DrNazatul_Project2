package com.example.a210279_khairulanwar_drnazatul_project2.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.a210279_khairulanwar_drnazatul_project2.*
import com.example.a210279_khairulanwar_drnazatul_project2.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(viewModel: ScanBuddyViewModel, navController: NavHostController) {

    // ── State ────────────────────────────────────────────────
    var step              by remember { mutableStateOf(0) }
    var name              by remember { mutableStateOf("") }
    var skinType          by remember { mutableStateOf("") }
    var skinConditions    by remember { mutableStateOf(setOf<String>()) }
    var hairConditions    by remember { mutableStateOf(setOf<String>()) }
    var bodyConditions    by remember { mutableStateOf(setOf<String>()) }
    var allergens         by remember { mutableStateOf(setOf<String>()) }
    var dietTypes         by remember { mutableStateOf(setOf<String>()) }
    var bannedIngredients by remember { mutableStateOf("") }
    var safeIngredients   by remember { mutableStateOf("") }
    var showError         by remember { mutableStateOf(false) }

    val totalSteps = 6

    Box(modifier = Modifier.fillMaxSize()) {
        Image(
            painter = painterResource(id = R.drawable.bg),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Surface(
            modifier = Modifier.fillMaxSize(),
            color = Color.White.copy(alpha = 0.15f)
        ) {
            Column(modifier = Modifier.fillMaxSize().padding(20.dp)) {

                Spacer(modifier = Modifier.height(40.dp))

                // ── Progress Header ──
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (step > 0) {
                        IconButton(onClick = { step--; showError = false }) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, null)
                        }
                    } else {
                        Spacer(modifier = Modifier.width(48.dp))
                    }
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(modifier = Modifier.size(52.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                            Text("🐱", fontSize = 28.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("ScanBuddy", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Step ${step + 1} of $totalSteps", color = MaterialTheme.colorScheme.outline, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(48.dp))
                }

                Spacer(modifier = Modifier.height(10.dp))

                LinearProgressIndicator(
                    progress = { (step + 1) / totalSteps.toFloat() },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f),
                    strokeCap = StrokeCap.Round
                )

                Spacer(modifier = Modifier.height(20.dp))

                // ── Step Content ──
                Column(modifier = Modifier.weight(1f).verticalScroll(rememberScrollState())) {

                    when (step) {

                        // STEP 0 — Name
                        0 -> {
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("👤 User Identity", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("Enter your name. Different names will have different product lists.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.height(20.dp))
                                    OutlinedTextField(
                                        value = name, onValueChange = { name = it },
                                        label = { Text("User Name") },
                                        leadingIcon = { Icon(Icons.Default.Person, null) },
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(12.dp),
                                        isError = showError && name.isBlank(),
                                        singleLine = true
                                    )
                                    if (showError && name.isBlank()) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text("⚠️ Please enter a name", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        // STEP 1 — Skin Type (single choice)
                        1 -> {
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("💧 What is your skin type?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("Select one that best describes your skin", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    SKIN_TYPES.forEach { option ->
                                        SingleChoiceItem(
                                            text = option,
                                            selected = skinType == option,
                                            onClick = { skinType = option; showError = false }
                                        )
                                        Spacer(modifier = Modifier.height(8.dp))
                                    }
                                    if (showError && skinType.isBlank()) {
                                        Text("⚠️ Please select your skin type", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        // STEP 2 — Skin Conditions (multiple)
                        2 -> {
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("✨ Skin Conditions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("Select all that apply (optional)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    MultiChoiceGrid(options = SKIN_CONDITIONS, selected = skinConditions) { opt ->
                                        skinConditions = if (skinConditions.contains(opt)) skinConditions - opt else skinConditions + opt
                                    }
                                }
                            }
                        }

                        // STEP 3 — Hair & Body Conditions (multiple)
                        3 -> {
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("💇 Hair Conditions", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("Select all that apply (optional)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    MultiChoiceGrid(options = HAIR_CONDITIONS, selected = hairConditions) { opt ->
                                        hairConditions = if (hairConditions.contains(opt)) hairConditions - opt else hairConditions + opt
                                    }
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Text("🧴 Body Conditions", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    MultiChoiceGrid(options = BODY_CONDITIONS, selected = bodyConditions) { opt ->
                                        bodyConditions = if (bodyConditions.contains(opt)) bodyConditions - opt else bodyConditions + opt
                                    }
                                }
                            }
                        }

                        // STEP 4 — Allergens & Diet (multiple)
                        4 -> {
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("⚠️ Allergies & Sensitivities", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("Select all ingredients you are allergic or sensitive to", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    MultiChoiceGrid(options = ALLERGEN_OPTIONS, selected = allergens) { opt ->
                                        allergens = if (allergens.contains(opt)) allergens - opt else allergens + opt
                                    }
                                    Spacer(modifier = Modifier.height(20.dp))
                                    Text("🥗 Diet Type", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Text("Select all that apply", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.height(12.dp))
                                    MultiChoiceGrid(options = DIET_OPTIONS, selected = dietTypes) { opt ->
                                        dietTypes = if (dietTypes.contains(opt)) dietTypes - opt else dietTypes + opt
                                    }
                                }
                            }
                        }

                        // STEP 5 — Ingredients + Summary
                        5 -> {
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("🧪 Ingredient Preferences", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                    Text("Optional — add specific ingredients to track", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                    Spacer(modifier = Modifier.height(16.dp))
                                    OutlinedTextField(
                                        value = safeIngredients, onValueChange = { safeIngredients = it },
                                        label = { Text("✅ Safe Ingredients (can use)") },
                                        placeholder = { Text("e.g. Aloe Vera, Vitamin C, Niacinamide") },
                                        leadingIcon = { Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF4CAF50)) },
                                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), minLines = 2
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    OutlinedTextField(
                                        value = bannedIngredients, onValueChange = { bannedIngredients = it },
                                        label = { Text("🚫 Banned Ingredients (avoid)") },
                                        placeholder = { Text("e.g. Paraben, Sulfate, Retinol") },
                                        leadingIcon = { Icon(Icons.Default.Close, null, tint = Color(0xFFF44336)) },
                                        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), minLines = 2
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Profile Summary Card
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                                Column(modifier = Modifier.padding(20.dp)) {
                                    Text("📋 Profile Summary", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                    Spacer(modifier = Modifier.height(10.dp))
                                    SummaryRow("👤 Name", name)
                                    SummaryRow("💧 Skin Type", skinType)
                                    if (skinConditions.isNotEmpty()) SummaryRow("✨ Skin", skinConditions.joinToString(", "))
                                    if (hairConditions.isNotEmpty()) SummaryRow("💇 Hair", hairConditions.joinToString(", "))
                                    if (bodyConditions.isNotEmpty()) SummaryRow("🧴 Body", bodyConditions.joinToString(", "))
                                    if (allergens.isNotEmpty()) SummaryRow("⚠️ Allergens", allergens.joinToString(", "))
                                    if (dietTypes.isNotEmpty()) SummaryRow("🥗 Diet", dietTypes.joinToString(", "))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // ── Next / Finish Button ──
                Button(
                    onClick = {
                        when (step) {
                            0 -> {
                                if (name.isBlank()) {
                                    showError = true
                                } else {
                                    showError = false
                                    // ── MULTI-USER: Load existing data if name matches ──
                                    viewModel.loginOrSwitchUser(name)
                                    val existing = viewModel.userProfile.value
                                    if (existing.name == name && existing.skinType.isNotBlank()) {
                                        // Fill the form from saved data
                                        skinType = existing.skinType
                                        skinConditions = existing.skinCondition.split(", ").filter { it.isNotBlank() }.toSet()
                                        hairConditions = existing.hairCondition.split(", ").filter { it.isNotBlank() }.toSet()
                                        bodyConditions = existing.bodyCondition.split(", ").filter { it.isNotBlank() }.toSet()
                                        allergens = existing.allergens.split(", ").filter { it.isNotBlank() }.toSet()
                                        dietTypes = existing.dietType.split(", ").filter { it.isNotBlank() }.toSet()
                                        bannedIngredients = existing.bannedIngredients
                                        safeIngredients = existing.safeIngredients
                                    }
                                    step++
                                }
                            }
                            1 -> if (skinType.isBlank()) showError = true else { showError = false; step++ }
                            5 -> {
                                viewModel.saveProfile(UserProfile(
                                    name              = name,
                                    skinType          = skinType,
                                    skinCondition     = skinConditions.joinToString(", "),
                                    hairCondition     = hairConditions.joinToString(", "),
                                    bodyCondition     = bodyConditions.joinToString(", "),
                                    allergens         = allergens.joinToString(", "),
                                    dietType          = dietTypes.joinToString(", "),
                                    bannedIngredients = bannedIngredients,
                                    safeIngredients   = safeIngredients
                                ))
                                navController.navigate(Screen.Home.route) {
                                    popUpTo(Screen.ProfileSetup.route) { inclusive = true }
                                }
                            }
                            else -> { showError = false; step++ }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(55.dp),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Text(
                        if (step == 5) "Finish & Start Scanning" else "Continue",
                        fontWeight = FontWeight.Bold, fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, null)
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

// ── Reusable choice components ────────────────────────────────────────────────

@Composable
fun SingleChoiceItem(text: String, selected: Boolean, onClick: () -> Unit) {
    OutlinedCard(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            width = if (selected) 2.dp else 1.dp,
            color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
        ),
        colors = CardDefaults.outlinedCardColors(
            containerColor = if (selected) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
        )
    ) {
        Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = selected, onClick = onClick)
            Spacer(modifier = Modifier.width(8.dp))
            Text(text, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
fun MultiChoiceGrid(options: List<String>, selected: Set<String>, onToggle: (String) -> Unit) {
    // 2-column wrap layout
    val rows = options.chunked(2)
    rows.forEach { rowItems ->
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            rowItems.forEach { option ->
                val isSelected = selected.contains(option)
                OutlinedCard(
                    onClick = { onToggle(option) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                    ),
                    colors = CardDefaults.outlinedCardColors(
                        containerColor = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                    )
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = isSelected, onCheckedChange = { onToggle(option) }, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(option, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal, color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
            // Fill empty slot if odd number
            if (rowItems.size == 1) Spacer(modifier = Modifier.weight(1f))
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
fun SummaryRow(label: String, value: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
        Text(label, fontSize = 13.sp, color = MaterialTheme.colorScheme.outline, modifier = Modifier.width(110.dp))
        Text(value, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
    }
}
