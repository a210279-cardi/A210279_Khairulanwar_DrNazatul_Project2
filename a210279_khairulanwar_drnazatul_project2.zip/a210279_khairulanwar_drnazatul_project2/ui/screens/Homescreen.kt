package com.example.a210279_khairulanwar_drnazatul_project2.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.a210279_khairulanwar_drnazatul_project2.Screen
import com.example.a210279_khairulanwar_drnazatul_project2.ScanBuddyViewModel
import com.example.a210279_khairulanwar_drnazatul_project2.ui.components.*
import com.example.a210279_khairulanwar_drnazatul_project2.R

@Composable
fun HomeScreen(viewModel: ScanBuddyViewModel, navController: NavHostController) {
    val userProfile by viewModel.userProfile.collectAsState()
    val products by viewModel.products.collectAsState()

    val safeCount   = products.count { it.safetyStatus == "Safe" }
    val unsafeCount = products.count { it.safetyStatus == "Avoid" }
    val avgScore    = if (products.isEmpty()) 0 else products.sumOf { it.healthScore } / products.size

    val textShadow = Shadow(
        color = Color.Black.copy(alpha = 0.6f),
        offset = Offset(2f, 2f),
        blurRadius = 4f
    )

    Box(modifier = Modifier.fillMaxSize()) {
        // ── Background Image ──
        Image(
            painter = painterResource(id = R.drawable.background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Dark overlay
        Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.35f)))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {

            // ── Header ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("🐱", fontSize = 26.sp)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    "ScanBuddy",
                    style = MaterialTheme.typography.headlineMedium.copy(shadow = textShadow),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.weight(1f))
                IconButton(
                    onClick = { navController.navigate(Screen.ProfileSetup.route) },
                    modifier = Modifier
                        .size(45.dp)
                        .background(Color.White.copy(alpha = 0.2f), CircleShape)
                ) {
                    Icon(Icons.Default.Person, null, tint = Color.White)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ── Welcome Text ──
            Text(
                "Welcome back,",
                style = MaterialTheme.typography.bodyMedium.copy(shadow = textShadow),
                color = Color.White.copy(alpha = 0.9f)
            )
            Text(
                userProfile.name.ifBlank { "User" },
                style = MaterialTheme.typography.headlineLarge.copy(shadow = textShadow),
                color = Color.White,
                fontWeight = FontWeight.ExtraBold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Scan smarter. Live better.",
                style = MaterialTheme.typography.bodySmall.copy(shadow = textShadow),
                color = Color.White.copy(alpha = 0.8f),
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(24.dp))

            // ── Scan Banner ──
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.9f),
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.9f)
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Scan a Product",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Barcode · Label Photo · AI Search",
                        color = Color.White.copy(alpha = 0.8f),
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { navController.navigate(Screen.Scan.route) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(Icons.Default.QrCodeScanner, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            "Start Scanning",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Stats ──
            Text(
                "My Stats",
                style = MaterialTheme.typography.titleMedium.copy(shadow = textShadow),
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatCard(modifier = Modifier.weight(1f), emoji = "✅", value = "$safeCount",   label = "Safe",      color = Color(0xFF4CAF50))
                StatCard(modifier = Modifier.weight(1f), emoji = "⚠️", value = "$unsafeCount", label = "Unsafe",    color = Color(0xFFF44336))
                StatCard(modifier = Modifier.weight(1f), emoji = "📊", value = "$avgScore",    label = "Avg Score", color = Color(0xFFFFD600))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Profile ──
            Text(
                "My Profile",
                style = MaterialTheme.typography.titleMedium.copy(shadow = textShadow),
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                ProfileInfoCard(
                    emoji = "💧", title = "Skin Type",
                    value = userProfile.skinType.ifBlank { "Not set" },
                    modifier = Modifier.weight(1f),
                    onClick = { navController.navigate(Screen.ProfileSetup.route) }
                )
                ProfileInfoCard(
                    emoji = "🥗", title = "Diet",
                    value = userProfile.dietType.ifBlank { "None" },
                    modifier = Modifier.weight(1f),
                    onClick = { navController.navigate(Screen.ProfileSetup.route) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            IngredientCard(
                emoji = "✅", title = "Safe Ingredients",
                value = userProfile.safeIngredients.ifBlank { "None set" },
                valueColor = Color(0xFF2E7D32),
                titleColor = Color(0xFF2E7D32),
                onClick = { navController.navigate(Screen.ProfileSetup.route) }
            )
            Spacer(modifier = Modifier.height(10.dp))
            IngredientCard(
                emoji = "🚫", title = "Banned Ingredients",
                value = userProfile.bannedIngredients.ifBlank { "None set" },
                valueColor = Color(0xFFC62828),
                titleColor = Color(0xFFC62828),
                onClick = { navController.navigate(Screen.ProfileSetup.route) }
            )
            Spacer(modifier = Modifier.height(10.dp))
            IngredientCard(
                emoji = "⚠️", title = "My Allergens",
                value = userProfile.allergens.ifBlank { "None set" },
                valueColor = Color(0xFFE65100),
                titleColor = Color(0xFFE65100),
                onClick = { navController.navigate(Screen.ProfileSetup.route) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // ── Recent Scans ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Recent Scans",
                    style = MaterialTheme.typography.titleMedium.copy(shadow = textShadow),
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                TextButton(onClick = { navController.navigate(Screen.ProductList.route) }) {
                    Text("See All →", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            if (products.isEmpty()) {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "No scans yet. Tap 'Start Scanning' to begin!",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            } else {
                products.take(3).forEach { product ->
                    RecentScanCard(product = product, onClick = {
                        viewModel.selectProduct(product)
                        navController.navigate(Screen.ProductDetail.route)
                    })
                    Spacer(modifier = Modifier.height(8.dp))
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // ── Community Hub ──
            Button(
                onClick = { navController.navigate(Screen.CommunityHub.route) },
                modifier = Modifier.fillMaxWidth().height(55.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(Icons.Default.Groups, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Community Hub", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}