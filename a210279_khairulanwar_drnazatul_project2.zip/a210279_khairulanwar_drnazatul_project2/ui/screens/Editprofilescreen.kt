package com.example.a210279_khairulanwar_drnazatul_project2.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.a210279_khairulanwar_drnazatul_project2.*
import com.example.a210279_khairulanwar_drnazatul_project2.ui.components.SectionTitle
import com.example.a210279_khairulanwar_drnazatul_project2.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(
    viewModel: ScanBuddyViewModel,
    navController: NavHostController,
    editType: String
) {
    val profile by viewModel.userProfile.collectAsState()
    var showSuccess by remember { mutableStateOf(false) }

    // Single-value fields
    var skinType          by remember { mutableStateOf(profile.skinType) }
    var safeIngredients   by remember { mutableStateOf(profile.safeIngredients) }
    var bannedIngredients by remember { mutableStateOf(profile.bannedIngredients) }

    // Multiple-choice fields — convert stored CSV back to Set
    var skinConditions by remember {
        mutableStateOf(
            profile.skinCondition.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
    }
    var hairConditions by remember {
        mutableStateOf(
            profile.hairCondition.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
    }
    var bodyConditions by remember {
        mutableStateOf(
            profile.bodyCondition.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
    }
    var allergens by remember {
        mutableStateOf(
            profile.allergens.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
    }
    var dietTypes by remember {
        mutableStateOf(
            profile.dietType.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toSet()
        )
    }

    val screenTitle = when (editType) {
        "skin_type"          -> "Edit Skin Type"
        "skin_condition"     -> "Edit Skin Conditions"
        "hair_condition"     -> "Edit Hair Conditions"
        "body_condition"     -> "Edit Body Conditions"
        "safe_ingredients"   -> "Edit Safe Ingredients"
        "banned_ingredients" -> "Edit Banned Ingredients"
        "allergens"          -> "Edit Allergens"
        "diet_type"          -> "Edit Diet Type"
        else                 -> "Edit Profile"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(screenTitle) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {

            Image(
                painter = painterResource(id = R.drawable.bg),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "A210279 | ${profile.name}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(12.dp))

                ElevatedCard(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {

                        when (editType) {

                            "skin_type" -> {
                                SectionTitle("💧 Skin Type")
                                Spacer(modifier = Modifier.height(12.dp))
                                SKIN_TYPES.forEach { option ->
                                    SingleChoiceItem(
                                        text = option,
                                        selected = skinType == option,
                                        onClick = { skinType = option }
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                }
                            }

                            "skin_condition" -> {
                                SectionTitle("✨ Skin Conditions")
                                Text(
                                    "Select all that apply",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                MultiChoiceGrid(options = SKIN_CONDITIONS, selected = skinConditions) { opt ->
                                    skinConditions = if (skinConditions.contains(opt))
                                        skinConditions - opt else skinConditions + opt
                                }
                            }

                            "hair_condition" -> {
                                SectionTitle("💇 Hair Conditions")
                                Text(
                                    "Select all that apply",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                MultiChoiceGrid(options = HAIR_CONDITIONS, selected = hairConditions) { opt ->
                                    hairConditions = if (hairConditions.contains(opt))
                                        hairConditions - opt else hairConditions + opt
                                }
                            }

                            "body_condition" -> {
                                SectionTitle("🧴 Body Conditions")
                                Text(
                                    "Select all that apply",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                MultiChoiceGrid(options = BODY_CONDITIONS, selected = bodyConditions) { opt ->
                                    bodyConditions = if (bodyConditions.contains(opt))
                                        bodyConditions - opt else bodyConditions + opt
                                }
                            }

                            "allergens" -> {
                                SectionTitle("⚠️ Allergens & Sensitivities")
                                Text(
                                    "Select all that apply",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                // ALLERGEN_OPTIONS is defined in Models.kt
                                MultiChoiceGrid(options = ALLERGEN_OPTIONS, selected = allergens) { opt ->
                                    allergens = if (allergens.contains(opt))
                                        allergens - opt else allergens + opt
                                }
                            }

                            "diet_type" -> {
                                SectionTitle("🥗 Diet Type")
                                Text(
                                    "Select all that apply",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                // DIET_TYPES is defined in Models.kt
                                MultiChoiceGrid(options = DIET_TYPES, selected = dietTypes) { opt ->
                                    dietTypes = if (dietTypes.contains(opt))
                                        dietTypes - opt else dietTypes + opt
                                }
                            }

                            "safe_ingredients" -> {
                                SectionTitle("✅ Safe Ingredients")
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = safeIngredients,
                                    onValueChange = { safeIngredients = it },
                                    label = { Text("Safe Ingredients") },
                                    placeholder = { Text("e.g. Aloe Vera, Vitamin C") },
                                    leadingIcon = {
                                        Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF4CAF50))
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    minLines = 4
                                )
                            }

                            "banned_ingredients" -> {
                                SectionTitle("🚫 Banned Ingredients")
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedTextField(
                                    value = bannedIngredients,
                                    onValueChange = { bannedIngredients = it },
                                    label = { Text("Banned Ingredients") },
                                    placeholder = { Text("e.g. Paraben, Alcohol") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Close, null, tint = Color(0xFFF44336))
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp),
                                    minLines = 4
                                )
                            }
                        }

                        // Success banner
                        if (showSuccess) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("✅", fontSize = 18.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "Saved successfully!",
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.Bold,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Save button
                        Button(
                            onClick = {
                                viewModel.saveProfile(
                                    profile.copy(
                                        skinType          = if (editType == "skin_type")          skinType                          else profile.skinType,
                                        skinCondition     = if (editType == "skin_condition")     skinConditions.joinToString(", ") else profile.skinCondition,
                                        hairCondition     = if (editType == "hair_condition")     hairConditions.joinToString(", ") else profile.hairCondition,
                                        bodyCondition     = if (editType == "body_condition")     bodyConditions.joinToString(", ") else profile.bodyCondition,
                                        allergens         = if (editType == "allergens")          allergens.joinToString(", ")      else profile.allergens,
                                        dietType          = if (editType == "diet_type")          dietTypes.joinToString(", ")      else profile.dietType,
                                        safeIngredients   = if (editType == "safe_ingredients")   safeIngredients                   else profile.safeIngredients,
                                        bannedIngredients = if (editType == "banned_ingredients") bannedIngredients                 else profile.bannedIngredients
                                    )
                                )
                                showSuccess = true
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(55.dp),
                            shape = RoundedCornerShape(15.dp)
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Save Changes", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedButton(
                            onClick = { navController.popBackStack() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(15.dp)
                        ) {
                            Text("Back", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}