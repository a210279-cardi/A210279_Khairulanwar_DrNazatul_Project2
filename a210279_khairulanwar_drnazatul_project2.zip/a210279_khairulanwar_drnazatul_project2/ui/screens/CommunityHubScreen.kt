package com.example.a210279_khairulanwar_drnazatul_project2.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.a210279_khairulanwar_drnazatul_project2.R
import com.example.a210279_khairulanwar_drnazatul_project2.ScanBuddyViewModel
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class CommunityPost(
    val productName: String = "",
    val category: String = "",
    val healthScore: Int = 0,
    val safetyStatus: String = "",
    val sharedBy: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommunityHubScreen(
    viewModel: ScanBuddyViewModel,
    navController: NavHostController
) {
    val profile      by viewModel.userProfile.collectAsState()
    val products     by viewModel.products.collectAsState()

    var communityPosts by remember { mutableStateOf<List<CommunityPost>>(emptyList()) }
    var isLoading      by remember { mutableStateOf(false) }
    var shareMessage   by remember { mutableStateOf("") }
    var showSnackbar   by remember { mutableStateOf(false) }

    val db = remember { FirebaseFirestore.getInstance() }

    // Load community posts from Firestore
    LaunchedEffect(Unit) {
        isLoading = true
        try {
            val snapshot = db.collection("community_scans")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .limit(20)
                .get()
                .await()
            communityPosts = snapshot.documents.mapNotNull { doc ->
                doc.toObject(CommunityPost::class.java)
            }
        } catch (e: Exception) {
            // Firestore not yet configured or offline — show empty state
        } finally {
            isLoading = false
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(showSnackbar) {
        if (showSnackbar) {
            snackbarHostState.showSnackbar(shareMessage)
            showSnackbar = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Community Hub") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primary,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter = painterResource(id = R.drawable.bg),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    text = "A210279 | ${profile.name}",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.6f)
                )
                Spacer(modifier = Modifier.height(12.dp))

                // ── Share Section ──
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Share, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Share to Community", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        }
                        Text(
                            "Upload your scanned products to Firebase Firestore and share with the community.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        if (products.isEmpty()) {
                            Text(
                                "No products to share yet. Scan a product first.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.outline
                            )
                        } else {
                            Text("Your recent scans:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            products.take(5).forEach { product ->
                                val scoreColor = when {
                                    product.healthScore >= 75 -> Color(0xFF2E7D32)
                                    product.healthScore >= 50 -> Color(0xFFF9A825)
                                    else -> Color(0xFFD50000)
                                }
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(product.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                        Text(product.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                    }
                                    Text("${product.healthScore}", color = scoreColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    OutlinedButton(
                                        onClick = {
                                            val post = hashMapOf(
                                                "productName"  to product.name,
                                                "category"     to product.category,
                                                "healthScore"  to product.healthScore,
                                                "safetyStatus" to product.safetyStatus,
                                                "sharedBy"     to profile.name,
                                                "timestamp"    to System.currentTimeMillis()
                                            )
                                            db.collection("community_scans").add(post)
                                                .addOnSuccessListener {
                                                    shareMessage = "✅ '${product.name}' shared to community!"
                                                    showSnackbar = true
                                                    // Refresh posts
                                                    db.collection("community_scans")
                                                        .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                                                        .limit(20)
                                                        .get()
                                                        .addOnSuccessListener { snapshot ->
                                                            communityPosts = snapshot.documents.mapNotNull { doc ->
                                                                doc.toObject(CommunityPost::class.java)
                                                            }
                                                        }
                                                }
                                                .addOnFailureListener {
                                                    shareMessage = "⚠️ Failed to share. Check Firebase setup."
                                                    showSnackbar = true
                                                }
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("Share", fontSize = 11.sp)
                                    }
                                }
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // ── Community Feed ──
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Groups, null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Community Scans", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.weight(1f))
                            Text("Firebase Firestore", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        }
                        Text(
                            "Products shared by the community from Firestore cloud.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.outline
                        )
                        Spacer(modifier = Modifier.height(16.dp))

                        if (isLoading) {
                            Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator(modifier = Modifier.size(32.dp))
                            }
                        } else if (communityPosts.isEmpty()) {
                            Column(
                                modifier = Modifier.fillMaxWidth().padding(16.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.CloudOff, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    "No community posts yet.\nBe the first to share a scan!",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.outline,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        } else {
                            communityPosts.forEach { post ->
                                val scoreColor = when {
                                    post.healthScore >= 75 -> Color(0xFF2E7D32)
                                    post.healthScore >= 50 -> Color(0xFFF9A825)
                                    else -> Color(0xFFD50000)
                                }
                                Card(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                    shape = RoundedCornerShape(12.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(post.productName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                            Text(post.category, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                            Text("by ${post.sharedBy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("${post.healthScore}", color = scoreColor, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                            Text(post.safetyStatus, color = scoreColor, fontSize = 10.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}
