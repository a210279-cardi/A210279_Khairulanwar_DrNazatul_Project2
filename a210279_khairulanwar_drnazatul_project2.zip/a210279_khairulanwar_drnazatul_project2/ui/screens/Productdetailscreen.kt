package com.example.a210279_khairulanwar_drnazatul_project2.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.a210279_khairulanwar_drnazatul_project2.R
import com.example.a210279_khairulanwar_drnazatul_project2.RiskLevel
import com.example.a210279_khairulanwar_drnazatul_project2.ScanBuddyViewModel
import com.example.a210279_khairulanwar_drnazatul_project2.ui.components.RiskBadge

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductDetailScreen(viewModel: ScanBuddyViewModel, navController: NavHostController) {
    val product      by viewModel.selectedProduct.collectAsState()
    val profile      by viewModel.userProfile.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val isAiLoading  by viewModel.isAiLoading.collectAsState()
    var chatInput    by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Product Analysis") },
                navigationIcon = { IconButton(onClick = { navController.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.primary, titleContentColor = Color.White, navigationIconContentColor = Color.White)
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Image(painter = painterResource(id = R.drawable.bg), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))

            // ── FIX: return@Scaffold is now OUTSIDE all nested lambdas,
            //         directly inside the Scaffold content lambda ──
            if (product == null) {
                Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                    ElevatedCard(shape = RoundedCornerShape(20.dp)) {
                        Column(modifier = Modifier.padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.SearchOff, null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("Product not found", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(onClick = { navController.popBackStack() }) { Text("Go Back") }
                        }
                    }
                }
                return@Scaffold  // ← FIXED: now correctly placed after the Box closes
            }

            val item = product!!  // safe — only reached when product != null

            val scoreColor = when {
                item.healthScore >= 75 -> Color(0xFF2E7D32)
                item.healthScore >= 50 -> Color(0xFFF9A825)
                item.healthScore >= 25 -> Color(0xFFE65100)
                else                   -> Color(0xFFD50000)
            }
            val scoreBg = when {
                item.healthScore >= 75 -> Color(0xFFE8F5E9)
                item.healthScore >= 50 -> Color(0xFFFFFDE7)
                item.healthScore >= 25 -> Color(0xFFFFF3E0)
                else                   -> Color(0xFFFFEBEE)
            }

            Column(
                modifier = Modifier.fillMaxSize().padding(innerPadding).padding(20.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("A210279", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(12.dp))

                // ── Score Card ──
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.elevatedCardColors(containerColor = scoreBg)) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(item.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                        Text(item.category, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(16.dp))
                        Box(modifier = Modifier.size(110.dp).clip(CircleShape).background(scoreColor.copy(alpha = 0.15f)), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("${item.healthScore}", color = scoreColor, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                                Text("/100", color = scoreColor.copy(alpha = 0.6f), fontSize = 12.sp)
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(scoreColor.copy(alpha = 0.15f)).padding(horizontal = 16.dp, vertical = 6.dp)) {
                            Text(item.scoreLabel, color = scoreColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { item.healthScore / 100f },
                            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                            color = scoreColor, trackColor = scoreColor.copy(alpha = 0.15f), strokeCap = StrokeCap.Round
                        )

                        // ── AI Summary ──
                        if (item.aiSummary.isNotBlank()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("🤖", fontSize = 18.sp)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("AI Analysis", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(item.aiSummary, style = MaterialTheme.typography.bodySmall, lineHeight = 20.sp)
                                }
                            }
                        }

                        // ── Score Legend ──
                        Spacer(modifier = Modifier.height(12.dp))
                        ElevatedCard(
                            modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp),
                            colors = CardDefaults.elevatedCardColors(containerColor = scoreBg)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("📊 Compatibility Score: ${item.healthScore}%", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = scoreColor)
                                Spacer(modifier = Modifier.height(8.dp))
                                listOf(
                                    Triple("81-100%", "Sangat Sesuai ✅", Color(0xFF2E7D32)),
                                    Triple("61-80%",  "Sesuai 👍",        Color(0xFF4CAF50)),
                                    Triple("31-60%",  "Berhati-hati ⚠️",  Color(0xFFE65100)),
                                    Triple("0-30%",   "Tidak Sesuai 🚫",  Color(0xFFD50000))
                                ).forEach { (range, label, color) ->
                                    val isCurrent = when {
                                        item.healthScore >= 81 && range == "81-100%"             -> true
                                        item.healthScore in 61..80 && range == "61-80%"          -> true
                                        item.healthScore in 31..60 && range == "31-60%"          -> true
                                        item.healthScore <= 30 && range == "0-30%"               -> true
                                        else                                                      -> false
                                    }
                                    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(if (isCurrent) color else color.copy(alpha = 0.3f)))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("$range — $label", fontSize = 12.sp, fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal, color = if (isCurrent) color else MaterialTheme.colorScheme.outline)
                                    }
                                }
                            }
                        }

                        // ── Alternatives ──
                        if (item.alternatives.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text("💡 Better Alternatives", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                    Spacer(modifier = Modifier.height(8.dp))
                                    item.alternatives.forEach { alt ->
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
                                            Text("→", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text(alt, style = MaterialTheme.typography.bodySmall)
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(item.safetyNote, style = MaterialTheme.typography.bodySmall, color = scoreColor, textAlign = TextAlign.Center)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ── Banned Ingredients ──
                if (item.foundBannedList.isNotEmpty()) {
                    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp), colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFEBEE))) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("🚫 Banned Ingredients Found", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = Color(0xFFC62828))
                            Spacer(modifier = Modifier.height(8.dp))
                            item.foundBannedList.forEach { banned ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFC62828)))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(banned, color = Color(0xFFC62828), style = MaterialTheme.typography.bodySmall)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // ── Allergens ──
                if (item.foundAllergenList.isNotEmpty()) {
                    ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp), colors = CardDefaults.elevatedCardColors(containerColor = Color(0xFFFFF3E0))) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("⚠️ Allergens Detected", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall, color = Color(0xFFE65100))
                            Spacer(modifier = Modifier.height(8.dp))
                            item.foundAllergenList.forEach { allergen ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(Color(0xFFE65100)))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(allergen, color = Color(0xFFE65100), style = MaterialTheme.typography.bodySmall)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // ── Ingredient Analysis ──
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("🧪 Ingredient Analysis", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Text("Each ingredient rated by risk level", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            RiskBadge("Safe",     Color(0xFF2E7D32))
                            RiskBadge("Low",      Color(0xFFF9A825))
                            RiskBadge("Moderate", Color(0xFFE65100))
                            RiskBadge("High",     Color(0xFFD50000))
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(8.dp))

                        item.ingredientDetails.forEach { detail ->
                            val riskColor = when (detail.riskLevel) {
                                RiskLevel.SAFE     -> Color(0xFF2E7D32)
                                RiskLevel.LOW      -> Color(0xFFF9A825)
                                RiskLevel.MODERATE -> Color(0xFFE65100)
                                RiskLevel.HIGH     -> Color(0xFFD50000)
                            }
                            val riskLabel = when (detail.riskLevel) {
                                RiskLevel.SAFE     -> "Safe"
                                RiskLevel.LOW      -> "Low Risk"
                                RiskLevel.MODERATE -> "Moderate"
                                RiskLevel.HIGH     -> "High Risk"
                            }
                            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(detail.name, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                                    Text(detail.description, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(riskColor.copy(alpha = 0.15f)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Text(riskLabel, color = riskColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ── Product Info ──
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Product Info", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("📦 Barcode: ${item.barcode}", style = MaterialTheme.typography.bodySmall)
                        Text("📅 Scanned: ${item.dateScanned}", style = MaterialTheme.typography.bodySmall)
                        Text("🗂️ Category: ${item.category}", style = MaterialTheme.typography.bodySmall)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ── Profile Match ──
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Matched Against Your Profile", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("👤 ${profile.name}", style = MaterialTheme.typography.bodySmall)
                        Text("💧 Skin: ${profile.skinType}", style = MaterialTheme.typography.bodySmall)
                        if (profile.dietType.isNotBlank())          Text("🥗 Diet: ${profile.dietType}", style = MaterialTheme.typography.bodySmall)
                        if (profile.bannedIngredients.isNotBlank()) Text("🚫 Banned: ${profile.bannedIngredients}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFC62828))
                        if (profile.allergens.isNotBlank())         Text("⚠️ Allergens: ${profile.allergens}", style = MaterialTheme.typography.bodySmall, color = Color(0xFFE65100))
                        if (profile.safeIngredients.isNotBlank())   Text("✅ Safe: ${profile.safeIngredients}", style = MaterialTheme.typography.bodySmall, color = Color(0xFF2E7D32))
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // ── AI Chat ──
                ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(15.dp)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🤖", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("Ask AI about this product", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                                Text("Safety, ingredients, alternatives...", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                            }
                            Spacer(modifier = Modifier.weight(1f))
                            if (chatMessages.isNotEmpty()) {
                                TextButton(onClick = { viewModel.clearChat() }) { Text("Clear", style = MaterialTheme.typography.labelSmall) }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        if (chatMessages.isNotEmpty()) {
                            chatMessages.takeLast(8).forEach { msg ->
                                val isUser = msg.role == "user"
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
                                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                                ) {
                                    if (!isUser) {
                                        Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) { Text("🐱", fontSize = 14.sp) }
                                        Spacer(modifier = Modifier.width(6.dp))
                                    }
                                    Box(
                                        modifier = Modifier
                                            .widthIn(max = 260.dp)
                                            .clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp, bottomStart = if (isUser) 12.dp else 2.dp, bottomEnd = if (isUser) 2.dp else 12.dp))
                                            .background(if (isUser) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant)
                                            .padding(horizontal = 12.dp, vertical = 8.dp)
                                    ) {
                                        Text(msg.content, style = MaterialTheme.typography.bodySmall, color = if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        if (isAiLoading) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(modifier = Modifier.size(28.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) { Text("🐱", fontSize = 14.sp) }
                                Spacer(modifier = Modifier.width(8.dp))
                                Box(modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surfaceVariant).padding(horizontal = 12.dp, vertical = 8.dp)) {
                                    Text("...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                        }

                        val quickQuestions = listOf("Is this safe?", "Side effects?", "Better alternative?")
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            quickQuestions.forEach { q ->
                                FilterChip(selected = false, onClick = { if (!isAiLoading) viewModel.sendChatMessage(q, item) }, label = { Text(q, fontSize = 10.sp) })
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = chatInput,
                                onValueChange = { chatInput = it },
                                placeholder = { Text("Ask anything...", style = MaterialTheme.typography.bodySmall) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            IconButton(
                                onClick = {
                                    if (chatInput.isNotBlank() && !isAiLoading) {
                                        viewModel.sendChatMessage(chatInput, item)
                                        chatInput = ""
                                    }
                                },
                                modifier = Modifier.size(48.dp).clip(CircleShape)
                                    .background(if (!isAiLoading && chatInput.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, null, tint = Color.White)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))
                Button(onClick = { navController.popBackStack() }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(15.dp)) {
                    Text("Back", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }
    }
}