package com.example.a210279_khairulanwar_drnazatul_project2

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE userName = :userName ORDER BY dateScanned DESC")
    fun getProductsByUser(userName: String): Flow<List<Product>>

    @Query("SELECT * FROM products ORDER BY dateScanned DESC")
    fun getAllProducts(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Query("DELETE FROM products WHERE userName = :userName")
    suspend fun deleteProductsByUser(userName: String)

    @Query("DELETE FROM products")
    suspend fun deleteAllProducts()
}