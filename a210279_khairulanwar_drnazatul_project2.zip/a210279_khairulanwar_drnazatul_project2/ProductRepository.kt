package com.example.a210279_khairulanwar_drnazatul_project2

import kotlinx.coroutines.flow.Flow

class ProductRepository(private val productDao: ProductDao) {
    val allProducts: Flow<List<Product>> = productDao.getAllProducts()

    fun getProductsByUser(userName: String): Flow<List<Product>> {
        return productDao.getProductsByUser(userName)
    }

    suspend fun insertProduct(product: Product) {
        productDao.insertProduct(product)
    }

    suspend fun deleteProductsByUser(userName: String) {
        productDao.deleteProductsByUser(userName)
    }
}