package com.example.a210279_khairulanwar_drnazatul_project2

import android.graphics.Bitmap
import android.util.Base64
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.a210279_khairulanwar_drnazatul_lab5.ui.screens.ScanScreen
import com.example.a210279_khairulanwar_drnazatul_project2.ScanBuddyViewModel
import com.example.a210279_khairulanwar_drnazatul_project2.ui.screens.*
import java.io.ByteArrayOutputStream

@Composable
fun ScanBuddyApp() {
    val navController = rememberNavController()
    val viewModel: ScanBuddyViewModel = viewModel()

    NavHost(navController = navController, startDestination = Screen.ProfileSetup.route) {
        composable(Screen.ProfileSetup.route) { ProfileSetupScreen(viewModel, navController) }
        composable(Screen.Home.route)          { HomeScreen(viewModel, navController) }
        composable(
            route = Screen.Scan.route,
            arguments = listOf(navArgument("barcode") { type = NavType.StringType; nullable = true; defaultValue = null })
        ) { backStackEntry ->
            val barcode = backStackEntry.arguments?.getString("barcode")
            ScanScreen(viewModel, navController, barcode)
        }
        composable(Screen.ProductList.route)   { ProductListScreen(viewModel, navController) }
        composable(Screen.ProductDetail.route) { ProductDetailScreen(viewModel, navController) }
        composable(
            route     = Screen.EditProfile.route,
            arguments = listOf(navArgument("editType") { type = NavType.StringType })
        ) { backStackEntry ->
            val editType = backStackEntry.arguments?.getString("editType") ?: "skin_type"
            EditProfileScreen(viewModel, navController, editType)
        }
        composable(Screen.CommunityHub.route)  { CommunityHubScreen(viewModel, navController) }
    }
}

// ── Utility ──────────────────────────────────────────────────────────────────

fun bitmapToBase64(bitmap: Bitmap): String {
    val outputStream = ByteArrayOutputStream()
    bitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
    return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
}
