package com.example.a210279_khairulanwar_drnazatul_project2

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.util.UUID

// ── Navigation ──
sealed class Screen(val route: String) {
    object ProfileSetup : Screen("profile_setup")
    object Home : Screen("home")
    object Scan : Screen("scan?barcode={barcode}") {
        fun createRoute(barcode: String? = null) = if (barcode != null) "scan?barcode=$barcode" else "scan"
    }
    object ProductList : Screen("product_list")
    object ProductDetail : Screen("product_detail")
    object CommunityHub : Screen("community_hub")
    object EditProfile : Screen("edit_profile/{editType}") {
        fun createRoute(editType: String) = "edit_profile/$editType"
    }
}

// ── Profile Data ──
data class UserProfile(
    val name: String = "",
    val skinType: String = "",
    val skinCondition: String = "",
    val hairCondition: String = "",
    val bodyCondition: String = "",
    val allergens: String = "",
    val dietType: String = "",
    val bannedIngredients: String = "",
    val safeIngredients: String = ""
)

// ── Room Persistent Entity Mapping ──
@Entity(tableName = "products")
data class Product(
    @PrimaryKey
    val id: String = UUID.randomUUID().toString(),
    val userName: String = "", // Associated user name for multi-user support
    val name: String,
    val barcode: String = "N/A",
    val category: String,
    val ingredients: String,
    val dateScanned: String,
    val healthScore: Int = 0,
    val safetyStatus: String = "Unknown",

    // SQLite compatible fallback primitives
    val riskIngredientsJson: String = "[]",
    val alternativesJson: String = "[]",
    val aiSummary: String = "",
    val alertsJson: String = "[]"
) {
    // Dynamic property fields
    val riskIngredients: List<IngredientDetail>
        get() = try {
            Gson().fromJson(riskIngredientsJson, object : TypeToken<List<IngredientDetail>>() {}.type)
        } catch (e: Exception) { emptyList() }

    val alternatives: List<String>
        get() = try {
            Gson().fromJson(alternativesJson, object : TypeToken<List<String>>() {}.type)
        } catch (e: Exception) { emptyList() }

    val alerts: List<String>
        get() = try {
            Gson().fromJson(alertsJson, object : TypeToken<List<String>>() {}.type)
        } catch (e: Exception) { emptyList() }

    val scoreLabel: String
        get() = when {
            healthScore >= 75 -> "Safe"
            healthScore >= 50 -> "Caution"
            healthScore >= 25 -> "Warning"
            else              -> "Avoid"
        }

    // UI-specific computed properties
    val ingredientDetails: List<IngredientDetail> get() = riskIngredients
    val safetyNote: String get() = "Analyzed based on your personal health profile."
    val foundBannedList: List<String> get() = alerts.filter { it.contains("Banned", ignoreCase = true) || it.contains("Restricted", ignoreCase = true) }
    val foundAllergenList: List<String> get() = alerts.filter { !it.contains("Banned", ignoreCase = true) && !it.contains("Restricted", ignoreCase = true) }
    
    // Scanscreen compatibility
    val productName: String get() = name
    val success: Boolean get() = true
    val found: Boolean get() = true
}

data class IngredientDetail(
    val name: String,
    val riskLevel: RiskLevel,
    val description: String
)

enum class RiskLevel { SAFE, LOW, MODERATE, HIGH }
data class ChatMessage(val role: String, val content: String)

data class ScanResult(
    val success: Boolean,
    val found: Boolean = true,
    val productName: String = "",
    val category: String = "",
    val ingredients: String = ""
)

sealed class AddProductResult {
    object Success : AddProductResult()
    object AlreadyExists : AddProductResult()
}

// ── UI Selection Constants ──
val SKIN_TYPES = listOf("Normal", "Oily", "Dry", "Combination", "Sensitive")

val SKIN_CONDITIONS = listOf(
    "Acne-prone", "Eczema", "Psoriasis", "Rosacea",
    "Hyperpigmentation", "Fine Lines", "Large Pores", "Dullness"
)

val HAIR_CONDITIONS = listOf(
    "Dandruff", "Hair Loss", "Dry Scalp", "Oily Scalp",
    "Frizzy", "Damaged", "Color-treated"
)

val BODY_CONDITIONS = listOf(
    "Dryness", "Sensitive Skin", "Stretch Marks",
    "Cellulite", "Keratosis Pilaris", "Eczema-prone"
)

val DIET_OPTIONS = listOf("Vegan", "Vegetarian", "Halal", "Keto", "Gluten-Free", "Dairy-Free")
val DIET_TYPES = DIET_OPTIONS // Compatibility

val ALLERGEN_OPTIONS = listOf(
    "Fragrance", "Alcohol", "Paraben", "Sulfate", "Silicone",
    "Essential Oils", "Nut Oils", "Latex", "Gluten", "Soy"
)
