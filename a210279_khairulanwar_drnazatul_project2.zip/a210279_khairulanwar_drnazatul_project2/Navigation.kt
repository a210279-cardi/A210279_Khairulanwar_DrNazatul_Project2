package com.example.a210279_khairulanwar_drnazatul_project2

// Navigation telah dipindahkan ke ScanBuddyApp.kt
// Models (Screen, dll) telah dipindahkan ke Models.kt