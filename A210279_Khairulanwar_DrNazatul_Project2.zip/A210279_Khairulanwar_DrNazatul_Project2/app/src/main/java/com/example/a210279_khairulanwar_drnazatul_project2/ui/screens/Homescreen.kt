package com.example.a210279_khairulanwar_drnazatul_project2.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.example.a210279_khairulanwar_drnazatul_project2.Screen
import com.example.a210279_khairulanwar_drnazatul_project2.ScanBuddyViewModel
import com.example.a210279_khairulanwar_drnazatul_project2.ui.components.*
import com.example.a210279_khairulanwar_drnazatul_project2.R
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

@Composable
fun HomeScreen(viewModel: ScanBuddyViewModel, navController: NavHostController) {
    val profile  by viewModel.userProfile.collectAsState()
    val products by viewModel.products.collectAsState()

    val safeCount   = products.count { it.safetyStatus == "Safe" }
    val unsafeCount = products.count { it.safetyStatus != "Safe" && it.safetyStatus != "Unknown" }
    val avgScore    = if (products.isEmpty()) 0 else products.sumOf { it.healthScore } / products.size

    val scanLauncher = androidx.activity.compose.rememberLauncherForActivityResult(ScanContract()) { result ->
        if (result.contents != null) {
            navController.navigate(Screen.Scan.createRoute(result.contents))
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {

        // ── Background: your own photo (res/drawable/background.jpg/png) ──
        Image(
            painter = painterResource(id = R.drawable.background),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        // Semi-transparent overlay so text stays readable
        Box(modifier = Modifier.fillMaxSize().background(Color.White.copy(alpha = 0.82f)))

        Column(modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {

            // ── Header ──
            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) { Text("🐱", fontSize = 22.sp) }
                Spacer(modifier = Modifier.width(12.dp))
                Text("ScanBuddy", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.weight(1f))
                IconButton(onClick = {
                    navController.navigate(Screen.ProfileSetup.route) {
                        popUpTo(0) { inclusive = true }
                    }
                }) {
                    Icon(Icons.Default.Logout, "Switch User", tint = MaterialTheme.colorScheme.primary)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Text("Welcome back,", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.outline)
            Text(profile.name.ifBlank { "User" }, style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
            Spacer(modifier = Modifier.height(24.dp))

            // ── Scan Banner ──
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .clip(RoundedCornerShape(30.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                MaterialTheme.colorScheme.primaryContainer,
                                MaterialTheme.colorScheme.primary
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.QrCodeScanner, null, modifier = Modifier.size(50.dp), tint = Color.White)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Ready to scan?", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            scanLauncher.launch(ScanOptions().apply {
                                setPrompt("Scan product")
                                setBeepEnabled(true)
                            })
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Open Scanner", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Stats ──
            Text("My Stats", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard(modifier = Modifier.weight(1f), emoji = "✅", value = "$safeCount",   label = "Safe",   color = Color(0xFF4CAF50))
                StatCard(modifier = Modifier.weight(1f), emoji = "⚠️", value = "$unsafeCount", label = "Unsafe", color = Color(0xFFF44336))
                StatCard(modifier = Modifier.weight(1f), emoji = "📊", value = "$avgScore",    label = "Avg",    color = Color(0xFFFFD600))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Profile Cards ──
            Text("My Profile", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                ProfileInfoCard(
                    emoji = "💧", title = "Skin Type",
                    value = profile.skinType.ifBlank { "Not set" },
                    modifier = Modifier.weight(1f),
                    onClick = { navController.navigate(Screen.EditProfile.createRoute("skin_type")) }
                )
                ProfileInfoCard(
                    emoji = "🥗", title = "Diet",
                    value = profile.dietType.ifBlank { "None" },
                    modifier = Modifier.weight(1f),
                    onClick = { navController.navigate(Screen.EditProfile.createRoute("diet_type")) }
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
            IngredientCard(
                emoji = "🚫", title = "Banned",
                value = profile.bannedIngredients.ifBlank { "None set" },
                valueColor = Color(0xFFC62828), titleColor = Color(0xFFC62828),
                onClick = { navController.navigate(Screen.EditProfile.createRoute("banned_ingredients")) }
            )
            Spacer(modifier = Modifier.height(10.dp))
            IngredientCard(
                emoji = "⚠️", title = "Allergens",
                value = profile.allergens.ifBlank { "None set" },
                valueColor = Color(0xFFE65100), titleColor = Color(0xFFE65100),
                onClick = { navController.navigate(Screen.EditProfile.createRoute("allergens")) }
            )

            Spacer(modifier = Modifier.height(24.dp))

            // ── Recent Scans ──
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Recent Scans", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                TextButton(onClick = { navController.navigate(Screen.ProductList.route) }) { Text("See All →") }
            }
            if (products.isEmpty()) {
                ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        "No products for this user yet.",
                        modifier = Modifier.padding(16.dp),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.outline
                    )
                }
            } else {
                products.take(3).forEach { product ->
                    RecentScanCard(product = product, onClick = {
                        viewModel.selectProduct(product)
                        navController.navigate(Screen.ProductDetail.route)
                    })
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ── Community Hub (Cloud / Firebase) ──
            Button(
                onClick = { navController.navigate(Screen.CommunityHub.route) },
                modifier = Modifier.fillMaxWidth().height(55.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
            ) {
                Icon(Icons.Default.Groups, null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Community Hub", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}