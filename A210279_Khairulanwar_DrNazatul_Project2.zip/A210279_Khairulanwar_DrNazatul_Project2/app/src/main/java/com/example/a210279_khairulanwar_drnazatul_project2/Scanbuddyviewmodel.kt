package com.example.a210279_khairulanwar_drnazatul_project2

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ScanBuddyViewModel(application: Application) : AndroidViewModel(application) {

    private val sharedPrefs = application.getSharedPreferences("ScanBuddyPrefs", Context.MODE_PRIVATE)

    // ── Repository & DB ──────────────────────────────────────────────────────
    private val repository: ProductRepository

    // ── User Profile ─────────────────────────────────────────────────────────
    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    // ── Dynamic Products Flow (Filtered by User Name) ────────────────────────
    @OptIn(ExperimentalCoroutinesApi::class)
    val products: StateFlow<List<Product>> = _userProfile
        .map { it.name }
        .distinctUntilChanged()
        .flatMapLatest { name ->
            if (name.isBlank()) flowOf(emptyList())
            else repository.getProductsByUser(name)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        val db = ScanBuddyDatabase.getDatabase(application)
        repository = ProductRepository(db.productDao())
        loadLastProfile()
    }

    private fun loadLastProfile() {
        val lastUser = sharedPrefs.getString("last_user_name", null)
        if (lastUser != null) {
            val json = sharedPrefs.getString("profile_$lastUser", null)
            if (json != null) {
                try {
                    _userProfile.value = Gson().fromJson(json, UserProfile::class.java)
                } catch (e: Exception) { }
            }
        }
    }

    /**
     * Checks if a profile exists for this name and loads it, or sets a new one.
     */
    fun loginOrSwitchUser(name: String) {
        val json = sharedPrefs.getString("profile_$name", null)
        if (json != null) {
            try {
                _userProfile.value = Gson().fromJson(json, UserProfile::class.java)
            } catch (e: Exception) {
                _userProfile.value = UserProfile(name = name)
            }
        } else {
            _userProfile.value = UserProfile(name = name)
        }
        sharedPrefs.edit().putString("last_user_name", name).apply()
    }

    fun saveProfile(profile: UserProfile) {
        _userProfile.value = profile
        val json = Gson().toJson(profile)
        sharedPrefs.edit()
            .putString("profile_${profile.name}", json)
            .putString("last_user_name", profile.name)
            .apply()
    }

    // ── Selected Product ─────────────────────────────────────────────────────
    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    fun selectProduct(product: Product) {
        _selectedProduct.value = product
        _chatMessages.value = emptyList()
    }

    // ── Add Product ──────────────────────────────────────────────────────────
    suspend fun addProduct(product: Product): AddProductResult {
        val currentUser = _userProfile.value.name
        
        // Ensure the product is tagged with the current user
        val productWithUser = product.copy(userName = currentUser)
        
        val existing = products.value.any { 
            it.barcode == productWithUser.barcode && 
            productWithUser.barcode != "N/A" && 
            it.userName == currentUser 
        }
        
        if (existing) return AddProductResult.AlreadyExists

        val finalProduct = analyzeSafetyLocally(productWithUser)
        repository.insertProduct(finalProduct)
        _selectedProduct.value = finalProduct
        return AddProductResult.Success
    }

    private fun analyzeSafetyLocally(product: Product): Product {
        val profile = _userProfile.value
        var score = 100
        val alerts = mutableListOf<String>()
        val riskIngreds = mutableListOf<IngredientDetail>()
        val ingredientsStr = product.ingredients.lowercase()

        fun hasMatch(item: String): Boolean {
            if (item.isBlank()) return false
            val pattern = "\\b${Regex.escape(item.trim().lowercase())}\\b".toRegex()
            return pattern.containsMatchIn(ingredientsStr)
        }

        profile.bannedIngredients.split(",").forEach { item ->
            if (hasMatch(item)) {
                score -= 40
                alerts.add("🚫 Restricted: $item")
                riskIngreds.add(IngredientDetail(item, RiskLevel.HIGH, "On your restricted list."))
            }
        }

        profile.allergens.split(",").forEach { item ->
            if (hasMatch(item)) {
                score -= 30
                alerts.add("⚠️ Allergen: $item")
                riskIngreds.add(IngredientDetail(item, RiskLevel.HIGH, "Found in your allergens list."))
            }
        }

        if (profile.skinType == "Sensitive") {
            val irritants = listOf("fragrance", "parfum", "alcohol denat", "sls", "sulfate")
            irritants.forEach { if (hasMatch(it)) { score -= 15; alerts.add("🧴 Irritant: $it") } }
        }

        if (profile.dietType.contains("Halal", ignoreCase = true)) {
            if (hasMatch("alcohol") || hasMatch("ethanol")) {
                score -= 20
                alerts.add("☪️ Policy: Contains Alcohol")
            }
        }

        profile.safeIngredients.split(",").forEach { item ->
            if (hasMatch(item)) {
                score += 5
                alerts.add("✅ Beneficial: $item")
            }
        }

        score = score.coerceIn(0, 100)
        
        val dynamicSummary = when {
            score >= 90 -> "Excellent match! This product aligns perfectly with your health profile."
            score >= 70 -> "Good choice. It's safe to use, though it has minor ingredients to note."
            score >= 40 -> "Use with caution. Some ingredients might cause sensitivity or mismatch your goals."
            else -> "Avoid this product. It contains multiple ingredients flagged in your profile."
        }

        return product.copy(
            healthScore = score,
            aiSummary = dynamicSummary,
            alertsJson = Gson().toJson(alerts),
            riskIngredientsJson = Gson().toJson(riskIngreds),
            safetyStatus = when {
                score >= 75 -> "Safe"
                score >= 50 -> "Caution"
                else -> "Avoid"
            }
        )
    }

    // ── AI Chat ──────────────────────────────────────────────────────────────
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    fun clearChat() { _chatMessages.value = emptyList() }

    fun sendChatMessage(userMessage: String, product: Product) {
        val updated = _chatMessages.value + ChatMessage("user", userMessage)
        _chatMessages.value = updated
        _isAiLoading.value = true
        viewModelScope.launch {
            val reply = callClaudeApi(userMessage, product, updated)
            _chatMessages.value = _chatMessages.value + ChatMessage("assistant", reply)
            _isAiLoading.value = false
        }
    }

    private suspend fun callClaudeApi(
        userMessage: String,
        product: Product,
        history: List<ChatMessage>
    ): String {
        return try {
            val apiKey = BuildConfig.CLAUDE_API_KEY
            if (apiKey.isBlank()) return "⚠️ Claude API key not set."
            val profile = _userProfile.value
            val systemPrompt = "You are ScanBuddy. Product: ${product.name}. User: ${profile.name}, Skin: ${profile.skinType}."
            val messages = JSONArray()
            history.forEach { msg -> messages.put(JSONObject().put("role", msg.role).put("content", msg.content)) }
            val body = JSONObject().put("model", "claude-sonnet-4-20250514").put("max_tokens", 512).put("system", systemPrompt).put("messages", messages).toString()
            val client = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).build()
            val request = Request.Builder().url("https://api.anthropic.com/v1/messages").addHeader("x-api-key", apiKey).addHeader("anthropic-version", "2023-06-01").post(body.toRequestBody("application/json".toMediaTypeOrNull())).build()
            val response = client.newCall(request).execute()
            val json = JSONObject(response.body?.string() ?: "")
            json.getJSONArray("content").getJSONObject(0).getString("text")
        } catch (e: Exception) { "⚠️ Error: ${e.message}" }
    }

    // ── Image Scan ────────────────────────────────────────────────────────────
    private val _imageScanResult = MutableStateFlow<Product?>(null)
    val imageScanResult: StateFlow<Product?> = _imageScanResult.asStateFlow()
    fun clearImageScanResult() { _imageScanResult.value = null }

    fun analyzeIngredientImage(base64Image: String) {
        _isAiLoading.value = true
        viewModelScope.launch {
            val result = callClaudeVision(base64Image)
            _imageScanResult.value = result
            _isAiLoading.value = false
        }
    }

    private suspend fun callClaudeVision(base64Image: String): Product? {
        return try {
            val apiKey = BuildConfig.CLAUDE_API_KEY
            if (apiKey.isBlank()) return null
            val profile = _userProfile.value
            val prompt = "Return JSON: name, category, ingredients."
            val imageContent = JSONObject().put("type", "image").put("source", JSONObject().put("type", "base64").put("media_type", "image/jpeg").put("data", base64Image))
            val textContent = JSONObject().put("type", "text").put("text", prompt)
            val body = JSONObject().put("model", "claude-sonnet-4-20250514").put("max_tokens", 1024).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", JSONArray().put(imageContent).put(textContent)))).toString()
            val client = OkHttpClient.Builder().build()
            val request = Request.Builder().url("https://api.anthropic.com/v1/messages").addHeader("x-api-key", apiKey).addHeader("anthropic-version", "2023-06-01").post(body.toRequestBody("application/json".toMediaTypeOrNull())).build()
            val response = client.newCall(request).execute()
            val json = JSONObject(response.body?.string() ?: "")
            val text = json.getJSONArray("content").getJSONObject(0).getString("text").trim().removePrefix("```json").removeSuffix("```").trim()
            val data = JSONObject(text)
            Product(name = data.optString("name", "Product"), category = data.optString("category", "Unknown"), ingredients = data.optString("ingredients", ""), dateScanned = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date()))
        } catch (e: Exception) { null }
    }

    // ── Barcode Lookup ────────────────────────────────────────────────────────
    private val _isBarcodeLoading = MutableStateFlow(false)
    val isBarcodeLoading: StateFlow<Boolean> = _isBarcodeLoading.asStateFlow()
    private val _barcodeLookupResult = MutableStateFlow<Product?>(null)
    val barcodeLookupResult: StateFlow<Product?> = _barcodeLookupResult.asStateFlow()
    fun clearBarcodeLookup() { _barcodeLookupResult.value = null }

    fun lookupBarcode(barcode: String) {
        _isBarcodeLoading.value = true
        viewModelScope.launch {
            try {
                val response = RetrofitInstance.api.getProduct(barcode)
                if (response.status == 1 && response.product != null) {
                    val p = response.product
                    _barcodeLookupResult.value = Product(
                        name = p.product_name ?: "Unknown",
                        barcode = barcode,
                        category = p.categories ?: "Unknown",
                        ingredients = p.ingredients_text ?: "",
                        dateScanned = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
                    )
                }
            } catch (e: Exception) { } finally { _isBarcodeLoading.value = false }
        }
    }

    // ── Product Search ────────────────────────────────────────────────────────
    private val _isSearchLoading = MutableStateFlow(false)
    val isSearchLoading: StateFlow<Boolean> = _isSearchLoading.asStateFlow()
    private val _productSearchResult = MutableStateFlow<Product?>(null)
    val productSearchResult: StateFlow<Product?> = _productSearchResult.asStateFlow()
    fun clearSearchResult() { _productSearchResult.value = null }

    fun searchProduct(query: String) {
        _isSearchLoading.value = true
        viewModelScope.launch {
            try {
                val result = searchViaAI(query)
                _productSearchResult.value = result
            } catch (e: Exception) { } finally { _isSearchLoading.value = false }
        }
    }

    private suspend fun searchViaAI(query: String): Product? {
        return try {
            val apiKey = BuildConfig.CLAUDE_API_KEY
            if (apiKey.isBlank()) return null
            val prompt = "Return JSON for product '$query': name, category, ingredients."
            val body = JSONObject().put("model", "claude-sonnet-4-20250514").put("max_tokens", 1024).put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt))).toString()
            val client = OkHttpClient.Builder().build()
            val request = Request.Builder().url("https://api.anthropic.com/v1/messages").addHeader("x-api-key", apiKey).addHeader("anthropic-version", "2023-06-01").post(body.toRequestBody("application/json".toMediaTypeOrNull())).build()
            val response = client.newCall(request).execute()
            val json = JSONObject(response.body?.string() ?: "")
            val text = json.getJSONArray("content").getJSONObject(0).getString("text").trim().removePrefix("```json").removeSuffix("```").trim()
            val data = JSONObject(text)
            Product(name = data.optString("name", query), category = data.optString("category", "Unknown"), ingredients = data.optString("ingredients", ""), dateScanned = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date()))
        } catch (e: Exception) { null }
    }
}
