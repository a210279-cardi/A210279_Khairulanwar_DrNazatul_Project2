package com.example.a210279_khairulanwar_drnazatul_project2

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path

// =============================
// API SERVICE
// =============================

interface ProductApi {

    @GET("api/v0/product/{barcode}.json")
    suspend fun getProduct(
        @Path("barcode") barcode: String
    ): ProductResponse
}

// =============================
// RETROFIT INSTANCE
// =============================

object RetrofitInstance {

    val api: ProductApi by lazy {
        Retrofit.Builder()
            .baseUrl("https://world.openfoodfacts.org/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ProductApi::class.java)
    }
}

// =============================
// JSON DATA MODELS
// =============================

data class ProductResponse(
    val status: Int,
    val product: ProductData?
)

data class ProductData(
    val product_name: String?,
    val ingredients_text: String?,
    val categories: String?,
    val image_url: String?
)