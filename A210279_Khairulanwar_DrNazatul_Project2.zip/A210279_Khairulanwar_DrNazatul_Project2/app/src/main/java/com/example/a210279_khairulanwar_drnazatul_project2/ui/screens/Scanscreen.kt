package com.example.a210279_khairulanwar_drnazatul_project2.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.navigation.NavHostController
import com.example.a210279_khairulanwar_drnazatul_project2.AddProductResult
import com.example.a210279_khairulanwar_drnazatul_project2.Product
import com.example.a210279_khairulanwar_drnazatul_project2.R
import com.example.a210279_khairulanwar_drnazatul_project2.Screen
import com.example.a210279_khairulanwar_drnazatul_project2.ScanBuddyViewModel
import com.example.a210279_khairulanwar_drnazatul_project2.bitmapToBase64
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// =============================
// 📷 SCAN SCREEN — 4 Tabs
// =============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ScanScreen(
    viewModel      : ScanBuddyViewModel,
    navController  : NavHostController,
    initialBarcode : String? = null
) {
    var selectedTab    by remember { mutableIntStateOf(if (initialBarcode != null) 1 else 0) }
    var pendingBarcode by remember { mutableStateOf<String?>(null) }

    val tabs = listOf("📷 Label", "🔍 Barcode", "🔎 Search", "✍️ Manual")

    Scaffold(
        topBar = {
            TopAppBar(
                title          = { Text("Add Product") },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor             = MaterialTheme.colorScheme.primary,
                    titleContentColor          = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            Image(
                painter            = painterResource(id = R.drawable.bg),
                contentDescription = null,
                modifier           = Modifier.fillMaxSize(),
                contentScale       = ContentScale.Crop
            )
            Box(modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f)))

            Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor   = MaterialTheme.colorScheme.primary.copy(alpha = 0.92f),
                    contentColor     = Color.White,
                    divider = {}
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick  = { selectedTab = index },
                            text     = {
                                Text(
                                    title,
                                    fontSize   = 10.sp,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    maxLines   = 1
                                )
                            }
                        )
                    }
                }

                when (selectedTab) {
                    0 -> ImageScanTab(
                        viewModel      = viewModel,
                        navController  = navController,
                        pendingBarcode = pendingBarcode,
                        onClearBarcode = { pendingBarcode = null }
                    )
                    1 -> BarcodeScanTab(
                        viewModel      = viewModel,
                        navController  = navController,
                        initialBarcode = initialBarcode,
                        onNotFound     = { scannedBarcode ->
                            pendingBarcode = scannedBarcode
                            selectedTab    = 0
                        }
                    )
                    2 -> SearchTab(viewModel, navController)
                    3 -> ManualAddTab(viewModel, navController)
                }
            }
        }
    }
}

// =============================
// 📸 TAB 0: Image / Label Scan
// =============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageScanTab(
    viewModel      : ScanBuddyViewModel,
    navController  : NavHostController,
    pendingBarcode : String?  = null,
    onClearBarcode : () -> Unit = {}
) {
    val context         = LocalContext.current
    val isLoading       by viewModel.isAiLoading.collectAsState()
    val imageScanResult by viewModel.imageScanResult.collectAsState()

    var imageReady       by remember { mutableStateOf(false) }
    var showError        by remember { mutableStateOf(false) }
    var autoNavigated    by remember { mutableStateOf(false) }

    val redirectedFromBarcode = pendingBarcode != null

    val photoUri = remember {
        val photoFile = File(context.cacheDir, "scan_label_${System.currentTimeMillis()}.jpg")
        FileProvider.getUriForFile(context, "${context.packageName}.provider", photoFile)
    }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            imageReady = false; autoNavigated = false
            try {
                @Suppress("DEPRECATION")
                val bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, photoUri)
                viewModel.analyzeIngredientImage(bitmapToBase64(bitmap))
            } catch (e: Exception) { e.printStackTrace() }
        }
    }

    val galleryLauncher = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            imageReady = false; autoNavigated = false
            @Suppress("DEPRECATION")
            val bitmap = MediaStore.Images.Media.getBitmap(context.contentResolver, it)
            viewModel.analyzeIngredientImage(bitmapToBase64(bitmap))
        }
    }

    LaunchedEffect(imageScanResult) {
        imageScanResult?.let { result ->
            if (result.success && result.productName.isNotBlank() && result.ingredients.isNotBlank() && !autoNavigated) {
                autoNavigated = true
                when (viewModel.addProduct(result.copy(barcode = pendingBarcode ?: "N/A"))) {
                    is AddProductResult.Success, is AddProductResult.AlreadyExists -> {
                        onClearBarcode(); viewModel.clearImageScanResult()
                        navController.navigate(Screen.ProductDetail.route)
                    }
                }
            } else if (result.success && !result.found) {
                imageReady = false; showError = true; viewModel.clearImageScanResult()
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
        if (redirectedFromBarcode) {
            Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF8E1)), shape = RoundedCornerShape(14.dp)) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("🔍", fontSize = 22.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Barcode not in database", fontWeight = FontWeight.Bold, color = Color(0xFFE65100), style = MaterialTheme.typography.bodySmall)
                        Text("📸 Photograph ingredient label for AI analysis", color = Color(0xFF5D4037), style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
            Spacer(modifier = Modifier.height(12.dp))
        }

        ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CameraAlt, null, modifier = Modifier.size(52.dp), tint = MaterialTheme.colorScheme.primary)
                Text("Scan Ingredient Label", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("AI extracts ingredients automatically", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(20.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(onClick = { cameraLauncher.launch(photoUri) }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), enabled = !isLoading) {
                        Icon(Icons.Default.CameraAlt, null, modifier = Modifier.size(16.dp)); Spacer(modifier = Modifier.width(6.dp)); Text("Camera")
                    }
                    OutlinedButton(onClick = { galleryLauncher.launch("image/*") }, modifier = Modifier.weight(1f), shape = RoundedCornerShape(12.dp), enabled = !isLoading) {
                        Icon(Icons.Default.Image, null, modifier = Modifier.size(16.dp)); Spacer(modifier = Modifier.width(6.dp)); Text("Gallery")
                    }
                }

                if (isLoading) {
                    Spacer(modifier = Modifier.height(20.dp))
                    CircularProgressIndicator(modifier = Modifier.size(32.dp))
                    Text("🤖 AI analyzing label...", style = MaterialTheme.typography.bodySmall)
                }

                if (showError && !isLoading) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("⚠️ Couldn't read clearly. Try again or add manually.", color = Color(0xFFE65100), fontSize = 12.sp, textAlign = TextAlign.Center)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
        ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("🔄 How it works", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                HowItWorksRow("1️⃣", "Take a photo", "Point camera at ingredient list")
                HowItWorksRow("2️⃣", "AI analysis", "Claude Vision reads label instantly")
                HowItWorksRow("3️⃣", "Zero typing", "Everything is auto-filled for you")
            }
        }
    }
}

// =============================
// 🔍 TAB 1: Barcode Scan
// =============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarcodeScanTab(
    viewModel      : ScanBuddyViewModel,
    navController  : NavHostController,
    initialBarcode : String?  = null,
    onNotFound     : (String) -> Unit = {}
) {
    var barcode by remember { mutableStateOf(initialBarcode ?: "") }
    var autoNavigated by remember { mutableStateOf(false) }
    val isBarcodeLoading by viewModel.isBarcodeLoading.collectAsState()
    val barcodeResult    by viewModel.barcodeLookupResult.collectAsState()

    LaunchedEffect(Unit) { if (!initialBarcode.isNullOrBlank()) viewModel.lookupBarcode(initialBarcode) }

    LaunchedEffect(barcodeResult) {
        barcodeResult?.let { result ->
            if (result.success && result.found && result.productName.isNotBlank() && result.ingredients.isNotBlank() && !autoNavigated) {
                autoNavigated = true
                when (viewModel.addProduct(result)) {
                    is AddProductResult.Success, is AddProductResult.AlreadyExists -> navController.navigate(Screen.ProductDetail.route)
                }
            } else if (!autoNavigated && barcode.isNotBlank() && !result.found) {
                viewModel.clearBarcodeLookup(); onNotFound(barcode)
            }
            viewModel.clearBarcodeLookup()
        }
    }

    val scanLauncher = rememberLauncherForActivityResult(ScanContract()) { res ->
        if (res.contents != null) {
            barcode = res.contents; autoNavigated = false; viewModel.lookupBarcode(barcode)
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState()), horizontalAlignment = Alignment.CenterHorizontally) {
        ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.QrCodeScanner, null, modifier = Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
                Text("Barcode Scanner", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Search 100M+ products instantly", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(20.dp))
                Button(onClick = { autoNavigated = false; scanLauncher.launch(ScanOptions().apply { setPrompt("Scan product barcode"); setBeepEnabled(true); setOrientationLocked(false) }) }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(12.dp), enabled = !isBarcodeLoading) {
                    Icon(Icons.Default.QrCodeScanner, null); Spacer(modifier = Modifier.width(8.dp)); Text("Start Scanning")
                }
                if (isBarcodeLoading) {
                    Spacer(modifier = Modifier.height(16.dp)); CircularProgressIndicator(modifier = Modifier.size(32.dp))
                    Text("Searching databases...", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("📦 Recently Scanned Barcode", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                Text(if (barcode.isNotBlank()) barcode else "None", style = MaterialTheme.typography.bodyMedium, color = if (barcode.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)
            }
        }
    }
}

// =============================
// 🔎 TAB 2: Product Search
// =============================

@Composable
fun SearchTab(viewModel: ScanBuddyViewModel, navController: NavHostController) {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    val isSearchLoading by viewModel.isSearchLoading.collectAsState()
    val searchResult    by viewModel.productSearchResult.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
        ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("🔎 AI Product Search", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Search by name or brand", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(value = query, onValueChange = { query = it; viewModel.clearSearchResult() }, label = { Text("Product name") }, leadingIcon = { Icon(Icons.Default.Search, null) }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true)
                Spacer(modifier = Modifier.height(12.dp))
                Button(onClick  = { if (query.isNotBlank()) viewModel.searchProduct(query) }, modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(12.dp), enabled = query.isNotBlank() && !isSearchLoading) {
                    if (isSearchLoading) { CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White); Spacer(modifier = Modifier.width(8.dp)); Text("Searching...") }
                    else { Icon(Icons.Default.Search, null); Spacer(modifier = Modifier.width(8.dp)); Text("Search & Analyze") }
                }
            }
        }

        searchResult?.let { result ->
            Spacer(modifier = Modifier.height(16.dp))
            ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp), colors = CardDefaults.elevatedCardColors(containerColor = if (result.found) Color(0xFFE8F5E9) else Color(0xFFFFF3E0))) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(if (result.found) "✅ Product Found" else "⚠️ Partial Result", fontWeight = FontWeight.Bold, color = if (result.found) Color(0xFF2E7D32) else Color(0xFFE65100))
                    Text("📦 ${result.productName}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Text("🗂️ ${result.category}", style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = { scope.launch { viewModel.addProduct(result); navController.navigate(Screen.ProductDetail.route) } }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp)) {
                        Icon(Icons.Default.CheckCircle, null); Spacer(modifier = Modifier.width(8.dp)); Text("Analyse This")
                    }
                }
            }
        }
    }
}

// =============================
// ✍️ TAB 3: Manual Entry (NEW)
// =============================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManualAddTab(viewModel: ScanBuddyViewModel, navController: NavHostController) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var ingredients by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var showError by remember { mutableStateOf(false) }
    val categories = listOf("Food & Drinks", "Skin Care", "Body Care", "Hair Care")

    Column(modifier = Modifier.fillMaxSize().padding(20.dp).verticalScroll(rememberScrollState())) {
        ElevatedCard(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp)) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text("✍️ Manual Product Entry", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("Fill in the details to analyze safety", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.outline)
                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Product Name") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), singleLine = true, isError = showError && name.isBlank())
                Spacer(modifier = Modifier.height(12.dp))

                ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                    OutlinedTextField(value = category, onValueChange = {}, readOnly = true, label = { Text("Category") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) }, modifier = Modifier.fillMaxWidth().menuAnchor(), shape = RoundedCornerShape(12.dp), isError = showError && category.isBlank())
                    ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        categories.forEach { cat -> DropdownMenuItem(text = { Text(cat) }, onClick = { category = cat; expanded = false }) }
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(value = ingredients, onValueChange = { ingredients = it }, label = { Text("Ingredients List") }, placeholder = { Text("e.g. Aqua, Glycerin, Phenoxyethanol...") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), minLines = 4, isError = showError && ingredients.isBlank())

                if (showError) {
                    Text("⚠️ Please fill all required fields", color = MaterialTheme.colorScheme.error, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                }

                Spacer(modifier = Modifier.height(20.dp))
                Button(
                    onClick = {
                        if (name.isBlank() || category.isBlank() || ingredients.isBlank()) { showError = true } 
                        else {
                            scope.launch {
                                viewModel.addProduct(Product(
                                    name = name, category = category, ingredients = ingredients,
                                    dateScanned = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
                                ))
                                navController.navigate(Screen.ProductDetail.route)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(55.dp),
                    shape = RoundedCornerShape(15.dp)
                ) {
                    Icon(Icons.Default.Analytics, null); Spacer(modifier = Modifier.width(8.dp)); Text("Save & Analyze", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ── Helpers ──
@Composable
fun HowItWorksRow(step: String, title: String, desc: String) {
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.Top) {
        Text(step, fontSize = 18.sp, modifier = Modifier.width(34.dp))
        Column {
            Text(title, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
            Text(desc, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
        }
    }
}
